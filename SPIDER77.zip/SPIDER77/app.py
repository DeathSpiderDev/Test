import os
from flask import Flask, render_template, request, redirect, url_for, flash, abort, send_from_directory, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
import docker
from werkzeug.utils import secure_filename
import bcrypt
import random
import string
from datetime import datetime
from config import Config

app = Flask(__name__)
app.config.from_object(Config)

# Initialize extensions
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Docker client
docker_client = docker.from_env()

# Create network if it doesn't exist
try:
    docker_client.networks.get(app.config['DOCKER_NETWORK'])
except docker.errors.NotFound:
    docker_client.networks.create(app.config['DOCKER_NETWORK'], driver='bridge')

# Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    containers = db.relationship('Container', backref='owner', lazy=True)

class Container(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)
    container_id = db.Column(db.String(100))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    port = db.Column(db.Integer)
    status = db.Column(db.String(20), default='stopped')
    container_type = db.Column(db.String(20))  # 'python' or 'node'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# User loader
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Helper functions
def generate_password_hash(password):
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def check_password_hash(hashed_password, password):
    return bcrypt.checkpw(password.encode('utf-8'), hashed_password.encode('utf-8'))

def find_available_port(start_port=8000, end_port=9000):
    used_ports = {container.port for container in Container.query.all() if container.port}
    for port in range(start_port, end_port + 1):
        if port not in used_ports:
            return port
    return None

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def get_container_volume_path(user_id, container_name):
    return os.path.join(app.config['UPLOAD_FOLDER'], f'user_{user_id}', container_name)

def get_container_stats(container_id):
    try:
        container = docker_client.containers.get(container_id)
        stats = container.stats(stream=False)
        return {
            'cpu_usage': stats['cpu_stats']['cpu_usage']['total_usage'],
            'memory_usage': stats['memory_stats']['usage'],
            'memory_limit': stats['memory_stats']['limit'],
            'network_rx': stats['networks']['eth0']['rx_bytes'],
            'network_tx': stats['networks']['eth0']['tx_bytes']
        }
    except:
        return None

# Routes
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if not username or not email or not password:
            flash('Please fill all fields', 'danger')
            return redirect(url_for('register'))
        
        if len(username) < 4 or len(username) > 20:
            flash('Username must be between 4 and 20 characters', 'danger')
            return redirect(url_for('register'))
        
        if len(password) < 8:
            flash('Password must be at least 8 characters', 'danger')
            return redirect(url_for('register'))
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return redirect(url_for('register'))
        
        if User.query.filter_by(username=username).first():
            flash('Username already taken', 'danger')
            return redirect(url_for('register'))
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'danger')
            return redirect(url_for('register'))
        
        hashed_password = generate_password_hash(password)
        new_user = User(username=username, email=email, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = True if request.form.get('remember') else False
        
        user = User.query.filter_by(username=username).first()
        
        if not user or not check_password_hash(user.password, password):
            flash('Invalid username or password', 'danger')
            return redirect(url_for('login'))
        
        login_user(user, remember=remember)
        next_page = request.args.get('next')
        return redirect(next_page) if next_page else redirect(url_for('dashboard'))
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    containers = Container.query.filter_by(user_id=current_user.id).all()
    
    # Update container statuses
    for container in containers:
        try:
            docker_container = docker_client.containers.get(container.container_id)
            container.status = docker_container.status
        except:
            container.status = 'not found'
    
    db.session.commit()
    return render_template('dashboard.html', containers=containers)

@app.route('/create_container', methods=['GET', 'POST'])
@login_required
def create_container():
    if request.method == 'POST':
        container_name = request.form.get('name')
        container_type = request.form.get('type')
        
        if not container_name or not container_type:
            flash('Please fill all fields', 'danger')
            return redirect(url_for('create_container'))
        
        if len(container_name) < 3 or len(container_name) > 30:
            flash('Container name must be between 3 and 30 characters', 'danger')
            return redirect(url_for('create_container'))
        
        if not container_name.isalnum():
            flash('Container name can only contain letters and numbers', 'danger')
            return redirect(url_for('create_container'))
        
        if Container.query.filter_by(name=container_name).first():
            flash('Container name already exists', 'danger')
            return redirect(url_for('create_container'))
        
        port = find_available_port()
        if not port:
            flash('No available ports', 'danger')
            return redirect(url_for('create_container'))
        
        try:
            if container_type == 'python':
                container = docker_client.containers.run(
                    'python:3.9-slim',
                    command='tail -f /dev/null',
                    detach=True,
                    name=f'user_{current_user.id}_{container_name}',
                    ports={'5000/tcp': port},
                    volumes={f'user_{current_user.id}_{container_name}': {'bind': '/app', 'mode': 'rw'}},
                    network=app.config['DOCKER_NETWORK'],
                    mem_limit='512m',
                    cpu_shares=512,
                    environment={'PYTHONUNBUFFERED': '1'}
                )
            elif container_type == 'node':
                container = docker_client.containers.run(
                    'node:16-alpine',
                    command='tail -f /dev/null',
                    detach=True,
                    name=f'user_{current_user.id}_{container_name}',
                    ports={'3000/tcp': port},
                    volumes={f'user_{current_user.id}_{container_name}': {'bind': '/app', 'mode': 'rw'}},
                    network=app.config['DOCKER_NETWORK'],
                    mem_limit='512m',
                    cpu_shares=512
                )
            else:
                flash('Invalid container type', 'danger')
                return redirect(url_for('create_container'))
            
            # Create volume directory
            volume_path = get_container_volume_path(current_user.id, container_name)
            os.makedirs(volume_path, exist_ok=True)
            
            new_container = Container(
                name=container_name,
                container_id=container.id,
                user_id=current_user.id,
                port=port,
                status='running',
                container_type=container_type
            )
            db.session.add(new_container)
            db.session.commit()
            
            flash('Container created successfully!', 'success')
            return redirect(url_for('container_details', container_id=new_container.id))
        
        except docker.errors.APIError as e:
            flash(f'Error creating container: {str(e)}', 'danger')
            return redirect(url_for('create_container'))
    
    return render_template('create_container.html')

@app.route('/container/<int:container_id>')
@login_required
def container_details(container_id):
    container = Container.query.get_or_404(container_id)
    if container.user_id != current_user.id:
        abort(403)
    
    # Get container info from Docker
    try:
        docker_container = docker_client.containers.get(container.container_id)
        container.status = docker_container.status
        db.session.commit()
        stats = get_container_stats(container.container_id)
    except docker.errors.NotFound:
        container.status = 'not found'
        db.session.commit()
        stats = None
    
    return render_template('container_details.html', 
                         container=container,
                         stats=stats)

@app.route('/container/<int:container_id>/files', methods=['GET', 'POST'])
@login_required
def container_files(container_id):
    container = Container.query.get_or_404(container_id)
    if container.user_id != current_user.id:
        abort(403)
    
    volume_path = get_container_volume_path(current_user.id, container.name)
    
    if request.method == 'POST':
        # Handle file upload
        if 'file' not in request.files:
            flash('No file part', 'danger')
            return redirect(url_for('container_files', container_id=container_id))
        
        file = request.files['file']
        if file.filename == '':
            flash('No selected file', 'danger')
            return redirect(url_for('container_files', container_id=container_id))
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(volume_path, filename))
            flash('File uploaded successfully', 'success')
            return redirect(url_for('container_files', container_id=container_id))
        else:
            flash('Invalid file type', 'danger')
    
    # Handle file deletion
    if request.method == 'DELETE':
        filename = request.form.get('filename')
        if filename:
            try:
                os.remove(os.path.join(volume_path, filename))
                return jsonify({'success': True})
            except:
                return jsonify({'success': False})
    
    # List files in volume
    try:
        files = []
        for f in os.listdir(volume_path):
            file_path = os.path.join(volume_path, f)
            files.append({
                'name': f,
                'size': os.path.getsize(file_path),
                'modified': datetime.fromtimestamp(os.path.getmtime(file_path))
            })
    except FileNotFoundError:
        os.makedirs(volume_path, exist_ok=True)
        files = []
    
    return render_template('container_files.html', 
                         container=container, 
                         files=files)

@app.route('/container/<int:container_id>/files/<filename>')
@login_required
def download_file(container_id, filename):
    container = Container.query.get_or_404(container_id)
    if container.user_id != current_user.id:
        abort(403)
    
    volume_path = get_container_volume_path(current_user.id, container.name)
    return send_from_directory(volume_path, filename, as_attachment=True)

@app.route('/container/<int:container_id>/console', methods=['GET', 'POST'])
@login_required
def container_console(container_id):
    container = Container.query.get_or_404(container_id)
    if container.user_id != current_user.id:
        abort(403)
    
    output = ""
    if request.method == 'POST':
        command = request.form.get('command')
        if command:
            try:
                docker_container = docker_client.containers.get(container.container_id)
                exec_instance = docker_container.exec_run(
                    command,
                    stdout=True,
                    stderr=True,
                    stdin=True,
                    tty=True,
                    workdir='/app',
                    environment={'TERM': 'xterm-color'}
                )
                output = exec_instance.output.decode('utf-8')
            except docker.errors.APIError as e:
                output = f"Error: {str(e)}"
    
    return render_template('container_console.html', 
                         container=container, 
                         output=output)

@app.route('/container/<int:container_id>/start')
@login_required
def start_container(container_id):
    container = Container.query.get_or_404(container_id)
    if container.user_id != current_user.id:
        abort(403)
    
    try:
        docker_container = docker_client.containers.get(container.container_id)
        docker_container.start()
        container.status = 'running'
        db.session.commit()
        flash('Container started successfully', 'success')
    except docker.errors.APIError as e:
        flash(f'Error starting container: {str(e)}', 'danger')
    
    return redirect(url_for('container_details', container_id=container_id))

@app.route('/container/<int:container_id>/stop')
@login_required
def stop_container(container_id):
    container = Container.query.get_or_404(container_id)
    if container.user_id != current_user.id:
        abort(403)
    
    try:
        docker_container = docker_client.containers.get(container.container_id)
        docker_container.stop()
        container.status = 'stopped'
        db.session.commit()
        flash('Container stopped successfully', 'success')
    except docker.errors.APIError as e:
        flash(f'Error stopping container: {str(e)}', 'danger')
    
    return redirect(url_for('container_details', container_id=container_id))

@app.route('/container/<int:container_id>/restart')
@login_required
def restart_container(container_id):
    container = Container.query.get_or_404(container_id)
    if container.user_id != current_user.id:
        abort(403)
    
    try:
        docker_container = docker_client.containers.get(container.container_id)
        docker_container.restart()
        container.status = 'running'
        db.session.commit()
        flash('Container restarted successfully', 'success')
    except docker.errors.APIError as e:
        flash(f'Error restarting container: {str(e)}', 'danger')
    
    return redirect(url_for('container_details', container_id=container_id))

@app.route('/container/<int:container_id>/delete', methods=['POST'])
@login_required
def delete_container(container_id):
    container = Container.query.get_or_404(container_id)
    if container.user_id != current_user.id:
        abort(403)
    
    try:
        docker_container = docker_client.containers.get(container.container_id)
        docker_container.remove(force=True)
        
        # Remove volume directory
        volume_path = get_container_volume_path(current_user.id, container.name)
        if os.path.exists(volume_path):
            for root, dirs, files in os.walk(volume_path, topdown=False):
                for name in files:
                    os.remove(os.path.join(root, name))
                for name in dirs:
                    os.rmdir(os.path.join(root, name))
            os.rmdir(volume_path)
        
        db.session.delete(container)
        db.session.commit()
        flash('Container deleted successfully', 'success')
    except docker.errors.APIError as e:
        flash(f'Error deleting container: {str(e)}', 'danger')
    
    return redirect(url_for('dashboard'))

@app.route('/container/<int:container_id>/stats')
@login_required
def container_stats(container_id):
    container = Container.query.get_or_404(container_id)
    if container.user_id != current_user.id:
        abort(403)
    
    stats = get_container_stats(container.container_id)
    return jsonify(stats) if stats else jsonify({'error': 'Stats unavailable'})

# Initialize database
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=app.config['DEFAULT_PORT'])