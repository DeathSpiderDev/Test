import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your-secret-key-here'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///site.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = 'container_volumes'
    ALLOWED_EXTENSIONS = {'txt', 'py', 'js', 'json', 'html', 'css', 'md'}
    DOCKER_NETWORK = 'container_hosting_network'
    DEFAULT_PORT = 6219
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max upload size