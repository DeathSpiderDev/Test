// General utility functions
document.addEventListener('DOMContentLoaded', function() {
    // Enable tooltips everywhere
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Confirm before deleting
    const deleteForms = document.querySelectorAll('form[onsubmit="return confirm(\'Are you sure you want to delete this container?\');"]');
    deleteForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!confirm('Are you sure you want to delete this container?')) {
                e.preventDefault();
            }
        });
    });
    
    // Auto-scroll console output
    const consoleOutput = document.getElementById('console-output');
    if (consoleOutput) {
        consoleOutput.scrollTop = consoleOutput.scrollHeight;
    }
});